<?php 
$urls		="http://localhost/mp3musik";
$sitename 	="MP3Musik.id";
$motto		="Download and Stream free MP3";
$description="Download Lagu Mp3 Gratis MP3Musik.id -  Free Download Music And Video - , disini anda dapat mencari Lagu, Video, Wallpaper, dan Lirik Lagu tanpa Batas. dengan tampilan yang nyaman dan simple, anda dapat menjelajah secara cepat. coba sekarang!";
$keywords	="download mp3, download lagu , gratis, mp3 gratis, 3gp, download full album,download video lucu, download video viral, video berita, video lucu viral di dunia maya, download video keren, download lagu hits";
$gwtcode	="";
$kodeiklanbtndl ="http://download-direct.link/download-mp3/";
?>