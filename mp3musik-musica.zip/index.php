<?php include 'include/config.php' ?>
<?php include 'include/function.php' ?>
<?php $title = $sitename . ' - '. $motto;?>
	<?php include 'header.php' ?>
	<?php include 'searchview.php' ?>
    <?php include 'popularsong.php' ?>
    <?php include 'recent.php' ?>
    <?php include 'footer.php' ?>
</body>
</html>