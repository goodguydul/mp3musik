	<footer id="footer">
    <div class="container">
      <nav class="footer-menu">
        <div class="menu-footer-container">
          <ul id="menu-footer" class="menu">
            <li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-33">
              <a href=" <?php echo $urls?>/about/">About</a>
            </li>
            <li id="menu-item-28" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-28">
              <a href="<?php echo $urls?>/dmca/">DMCA</a>
            </li>
            <li id="menu-item-29" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29">
              <a href="<?php echo $urls?>/disclaimer/">Disclaimer</a>
            </li>
            <li id="menu-item-30" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30">
              <a href="<?php echo $urls?>/privacy/">Privacy</a>
            </li>
            <li id="menu-item-32" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-32">
              <a href="<?php echo $urls?>/contact/">Contact</a>
            </li>
          </ul>
        </div>
        <div class="credits" style="padding-top: 13px;">
          Copyright © 2017 <?php echo $sitename?>.
        </div>
      </nav>
    </div>
  </footer>
  <script type="text/javascript" src="<?php echo $urls?>/include/script.js"></script>
  <script type="text/javascript" src="<?php echo $urls?>/include/script-2.js"></script>