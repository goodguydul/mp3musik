<?php
$title='Disclaimer - Sukaa.Xyz';
$description='Sukaa.Xyz Gratis Download Musik Dan Video - Selamat Datang di sukaa.xyz, disini anda dapat mencari Lagu, Video, Wallpaper, dan Lirik Lagu tanpa Batas. dengan tampilan yang nyaman dan simple, anda dapat menjelajah secara cepat. coba sekarang!';
$keywords='download mp3, download lagu , gratis, mp3 gratis, 3gp, download full album';
include'head.php';
echo'<div align="left"><h1 class="bmenu1" align="center">Disclaimer</h1>
1. IsiLagu tidak menyimpan file musik yang ditampilkan pada situs ini. <br>
2. IsiLagu indexes these files which are located on remote servers which neither IsiLagu nor its affiliates have any connection with / control of / association with. <br>
3. You download mp3 files from another host service. (not from  IsiLagu) <br>
4. All music on is presented only for fact-finding listening. <br>
5. You must remove a song from the computer after listening. <br>
6. If You wont delete files from the computer Youll break the copyrights protection laws. <br>
7. All the rights on the songs are the property of their respective owners. <br>
8. IsiLagu is a search engine, but we respect an Copyright Laws. </div>';
include'foot.php';
?>